<?php

require_once 'requiresession.inc.php';

if(!isset($_GET['id']))
{
	header("location: index.php");
	exit();
}
// Read the JSON file 
$json = file_get_contents('userlist.json');
  
// Decode the JSON file
$json_data = json_decode($json,true);

for($x = 0; $x < sizeof($json_data["userlist"]); $x++)
{
	if($json_data["userlist"][$x]["identifier"] == $_GET['id'])
	{
		$json_data["userlist"][$x]["checked_in"] = 0;
	}
}

$userDB = fopen("userlist.json", "w"); 
fwrite($userDB, json_encode($json_data));
fclose($userDB);

header("location: index.php");
exit();