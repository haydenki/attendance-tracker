<?php 

// Read master key
$myfile = fopen("MASTERKEY", "r") or die("Unable to masterkey file!");
$masterkey = fread($myfile,filesize("MASTERKEY"));

if($_POST["key"] != $masterkey)
{
	die();
}

// Read the JSON file 
$json = file_get_contents('userlist.json');
  
// Decode the JSON file
$json_data = json_decode($json,true);

for($x = 0; $x < sizeof($json_data["userlist"]); $x++)
{
	if($json_data["userlist"][$x]["identifier"] == $_POST['id'])
	{
		if($json_data["userlist"][$x]["checked_in"] == 0)
		{
			$json_data["userlist"][$x]["time_in"] = time();
			$json_data["userlist"][$x]["checked_in"] = 1;
		}
		else
		{
			$json_data["userlist"][$x]["checked_in"] = 0;
		}
	}
}

die()